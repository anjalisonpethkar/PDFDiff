package PDFCOMP;
public enum CompareMode {
	TEXT_MODE,
	VISUAL_MODE
}
