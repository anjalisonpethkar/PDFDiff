package PDFCOMP;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;

import org.apache.commons.io.FileUtils;

public class ComparePDF {

	public static void main(String[] args) throws IOException {

		String TextLogfile;
		String ImageDest=args[0];
		TextLogfile=args[0]+"textlog.txt";
		String VisualLogfile;
		VisualLogfile=args[0]+"visual.txt";
		String file1,file2;
		file1=args[0]+args[1];
		file2=args[0]+args[2];
		PrintStream o = new PrintStream(new File(args[0]+"Logs.htm")); 
		System.setOut(o); 
		if (args[3].equalsIgnoreCase("Text")  || args[3].equalsIgnoreCase("Both") ) 
		{
			PDFUtil pdfutil1 = new PDFUtil();
			pdfutil1.setCompareMode(CompareMode.TEXT_MODE);
 	 		//pdfutil1.enableLog(TextLogfile); 
			pdfutil1.highlightPdfDifference(true);
			pdfutil1.setImageDestinationPath(ImageDest);
			pdfutil1.compare(file1, file2);
		}
		
		if (args[3].equalsIgnoreCase("Visual")  || args[3].equalsIgnoreCase("Both") ) 
		{
			PDFUtil pdfutil = new PDFUtil();
			pdfutil.setCompareMode(CompareMode.VISUAL_MODE);
			//pdfutil.enableLog(VisualLogfile);
			pdfutil.highlightPdfDifference(true);
			pdfutil.setImageDestinationPath(ImageDest);
			pdfutil.compare(file1, file2);
		}
	/*	File f1 = new File((args[0]+"Logs.txt"));
		File f2 = new File((args[0]+"Logs.htm"));
		FileUtils.copyFile(f1, f2);*/

	}

}
